/**
 *
 * @author Kumar Chandan
 */

import java.io.File;
import java.sql.Date;
import java.util.HashMap;

public class GlobalVar 
{	
	public static String defaultPath=System.getProperty("user.dir")+File.separator+"resource"+File.separator+"DBConfig.properties";
	public static String filepath;
}
